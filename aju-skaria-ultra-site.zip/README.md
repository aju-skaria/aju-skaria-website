
# aju-skaria.pro
Award‑grade static website. Free hosting via GitHub Pages.

## Upload
1) Create a public repo (e.g., `aju-skaria-website`).
2) Upload all files in this folder (keep **CNAME** as `aju-skaria.pro`).
3) Settings → Pages → Build and deployment: **Deploy from a branch** → `main` + `/root`.

## DNS (Name.com)
A  @  185.199.108.153
A  @  185.199.109.153
A  @  185.199.110.153
A  @  185.199.111.153
CNAME  www  {your_github_username}.github.io

## Edit
Open the HTML files, change text, commit.
