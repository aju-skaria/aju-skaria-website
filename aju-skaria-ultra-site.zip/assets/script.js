
const io = new IntersectionObserver(entries => {
  entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('in'); });
}, {threshold: 0.25});
document.querySelectorAll('.reveal').forEach(el => io.observe(el));

function calcKeyPerson(){
  const n = id => +document.getElementById(id).value.replace(/,/g,'') || 0;
  const rev = n('rev');
  const margin = n('margin')/100;
  const months = n('months');
  const prob = n('prob')/100;
  const loss = rev * margin * (months/12);
  const expected = loss * prob;
  const fmt = x => Math.round(x).toLocaleString();
  document.getElementById('outLoss').textContent = fmt(loss);
  document.getElementById('outExp').textContent = fmt(expected);
}
window.calcKeyPerson = calcKeyPerson;
